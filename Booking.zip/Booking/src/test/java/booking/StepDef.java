package booking;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.BookingPageBean;
import pages.LoginPageBean;

public class StepDef {
	
	private WebDriver driver;
	private LoginPageBean loginPageBean;
	private BookingPageBean bookingPageBean;
	
	@Before
	public void setUp()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\rakes\\Spring\\chromedriver.exe");
		driver=new ChromeDriver();
		loginPageBean= new LoginPageBean(driver);
		bookingPageBean= new BookingPageBean(driver);
	}
	@Given("^Login form is open$")
	public void login_form_is_open() throws Throwable {
		 driver.get("C:\\Users\\rakes\\BDD\\Booking\\src\\main\\webapp\\Login.html");
	    
	}

	@When("^I blindly click on login$")
	public void i_blindly_click_on_login() throws Throwable {
		loginPageBean.setBtn2();
	}

	@Then("^Alert message for user Name will be raised$")
	public void alert_message_for_user_Name_will_be_raised() throws Throwable {
		assertEquals(loginPageBean.getUser(), "* Please enter userName.");
    	Thread.sleep(500);
		/*assertEquals(driver.switchTo().alert().getText(), "Please fill the UserName");
    	Thread.sleep(500);*/
		 
	}

	@When("^I enter the user Name and press login$")
	public void i_enter_the_user_Name_and_press_login() throws Throwable {
		 loginPageBean.setUserName("capgemini");
		 loginPageBean.setBtn2(); 
		/*driver.switchTo().alert().accept();
		driver.navigate().refresh();
		loginPageBean.setUserName("cepgemini");
		loginPageBean.setBtn2();*/
	}

	@Then("^Alert message for password will be raised$")
	public void alert_message_for_password_will_be_raised() throws Throwable {
		assertEquals(loginPageBean.getPassword(), "* Please enter password.");
    	Thread.sleep(500);
	
		/*assertEquals(driver.switchTo().alert().getText(), "Please fill the Password");
    	Thread.sleep(500);*/
		}

	@When("^I enter the password and press login$")
	public void i_enter_the_password_and_press_login() throws Throwable {
		loginPageBean.setUserPassword("capg1234");
		/*driver.switchTo().alert().accept();
		driver.navigate().refresh();
		loginPageBean.setUserName("cepgemini");
		loginPageBean.setUserPassword("capg1234");
		loginPageBean.setBtn2(); */
	}

	@Then("^I am sent to HotelBooking\\.html page$")
	public void i_am_sent_to_HotelBooking_html_page() throws Throwable {
		loginPageBean.setBtn2();
		/*assertEquals(driver.switchTo().alert().getText(), "login details are validated.");
    	Thread.sleep(1500);
    	driver.switchTo().alert().accept();*/
			}

	@When("^Booking details page is open and i blinldly press confirm booking$")
	public void booking_details_page_is_open_and_i_blinldly_press_confirm_booking() throws Throwable {
	    bookingPageBean.setBtn();
	}

	@Then("^Alert message for first name is raised$")
	public void alert_message_for_first_name_is_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the First Name");
    	Thread.sleep(500);
	}

	@When("^I enter the first Name and press confirm booking$")
	public void i_enter_the_first_Name_and_press_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
	    bookingPageBean.setFirstName("Yamini");
	    bookingPageBean.setBtn();
	}

	@Then("^Alert message for last name will be raised$")
	public void alert_message_for_last_name_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Last Name");
    	Thread.sleep(500);
	}

	@When("^I enter the last Name and press confirm booking$")
	public void i_enter_the_last_Name_and_press_confirm_booking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().accept();
		//driver.navigate().refresh();
		//bookingPageBean.setFirstName("Manasa");
		bookingPageBean.setLastName("Ambati");
		bookingPageBean.setBtn(); 
	}

	@Then("^Alert message for email will be raised$")
	public void alert_message_for_email_will_be_raised() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Email");
    	//Thread.sleep(500);
	}

	@When("^I enter the invalid email and press confirm booking$")
	public void i_enter_the_invalid_email_and_press_confirm_booking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().accept();
		/*driver.navigate().refresh();
		bookingPageBean.setFirstName("Manasa");
		bookingPageBean.setLastName("Gundaji");*/
		bookingPageBean.setEmail("yaminiambati.gmailcom");
		bookingPageBean.setBtn(); 
	}

	@Then("^Alert message for enter valid email id will be raised$")
	public void alert_message_for_enter_valid_email_id_will_be_raised() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		assertEquals(driver.switchTo().alert().getText(), "Please enter valid Email Id.");
    	//Thread.sleep(500);
	}

	@When("^I enter the valid email and press confirm booking$")
	public void i_enter_the_valid_email_and_press_confirm_booking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().accept();
		/*driver.navigate().refresh();
		bookingPageBean.setFirstName("Manasa");
		bookingPageBean.setLastName("Gundaji");*/
		bookingPageBean.setEmail("yaminiambati@gmail.com");
		bookingPageBean.setBtn(); 
	}

	@Then("^Alert message for enter phoneno will be raised$")
	public void alert_message_for_enter_phoneno_will_be_raised() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Mobile No.");
    	Thread.sleep(500);
	}

	@When("^I enter the invalid phoneno  and press confirm booking$")
	public void i_enter_the_invalid_phoneno_and_press_confirm_booking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().accept();
		bookingPageBean.setPhone("242");
		bookingPageBean.setBtn(); 
	}

	@Then("^Alert message for enter valid phoneno will be raised$")
	public void alert_message_for_enter_valid_phoneno_will_be_raised() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		assertEquals(driver.switchTo().alert().getText(), "Please enter valid Contact no.");
    	Thread.sleep(500);
	}

	@When("^I enter the valid phoneno only and press confirm booking$")
	public void i_enter_the_valid_phoneno_only_and_press_confirm_booking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().accept();
		bookingPageBean.getPhone();
		bookingPageBean.setPhone("8977635974");
		bookingPageBean.setBtn();
	}
	@Then("^Alert message for address will be raised$")
	public void alert_message_for_address_will_be_raised() throws Throwable {
	   
		
	}

	@Then("^Alert message for no of people attending will be raised$")
	public void alert_message_for_no_of_people_attending_will_be_raised() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
	}

	@When("^I enter the address and press confirm booking$")
	public void i_enter_the_address_and_press_confirm_booking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		
		
	}

	@Then("^Alert message for enter city will be raised$")
	public void alert_message_for_enter_city_will_be_raised() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		assertEquals(driver.switchTo().alert().getText(), "Please select city");
    	Thread.sleep(500);
	}

	@When("^I enter the city and press confirm booking$")
	public void i_enter_the_city_and_press_confirm_booking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().accept();
		bookingPageBean.setCity("Chennai");
		bookingPageBean.setBtn();
	}

	@Then("^Alert message for enter state will be raised$")
	public void alert_message_for_enter_state_will_be_raised() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		assertEquals(driver.switchTo().alert().getText(), "Please select state");
    	Thread.sleep(500);
	}

	@When("^I enter the state and press confirm booking$")
	public void i_enter_the_state_and_press_confirm_booking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		driver.switchTo().alert().accept();
		bookingPageBean.setState("Tamilnadu");
		bookingPageBean.setBtn();
	}

	@Then("^Alert message for no of people staying will be raised$")
	public void alert_message_for_no_of_people_staying_will_be_raised() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
	}

	@When("^I enter the no of people staying and press confirm booking$")
	public void i_enter_the_no_of_people_staying_and_press_confirm_booking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		
		
	   
	}

	@Then("^Alert message for  no of room booked will be raised$")
	public void alert_message_for_no_of_room_booked_will_be_raised() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
	}

	@When("^I enter the no of room booked and press confirm booking$")
	public void i_enter_the_no_of_room_booked_and_press_confirm_booking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
	   
		
	}

	@Then("^Alert message for card holder name is raised$")
	public void alert_message_for_card_holder_name_is_raised() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Card holder name");
    	
	}

	@When("^I enter card holder name and press confirm booking$")
	public void i_enter_card_holder_name_and_press_confirm_booking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().accept();
		
	    bookingPageBean.setCardHolderName("Yamini Ambati");
	    bookingPageBean.setBtn();
	}

	@Then("^Alert message for enter debit card no will be raised$")
	public void alert_message_for_enter_debit_card_no_will_be_raised() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Debit card Number");
    	
	}

	@When("^I enter the enter debit card no press confirm booking$")
	public void i_enter_the_enter_debit_card_no_press_confirm_booking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().accept();
		
	    bookingPageBean.setDbCardNumber("1234123412341234");
	    bookingPageBean.setBtn();
		 
	}

	@Then("^Alert message for enter cvv no will be raised$")
	public void alert_message_for_enter_cvv_no_will_be_raised() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		assertEquals(driver.switchTo().alert().getText(), "Please fill the CVV");
    	//Thread.sleep(500);
	}

	@When("^I enter the cvv no and press confirm booking$")
	public void i_enter_the_cvv_no_and_press_confirm_booking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().accept();
		
	    bookingPageBean.setCvv("564");
	    bookingPageBean.setBtn();
	}

	@Then("^Alert message for enter expiry month will be raised$")
	public void alert_message_for_enter_expiry_month_will_be_raised() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		assertEquals(driver.switchTo().alert().getText(), "Please fill expiration month");
    	
	}

	@When("^I enter the expiry month and press confirm booking$")
	public void i_enter_the_expiry_month_and_press_confirm_booking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().accept();
		
	    bookingPageBean.setExpiryMonth("8");
	    bookingPageBean.setBtn();
	}

	@Then("^Alert message for expiry year will be raised$")
	public void alert_message_for_expiry_year_will_be_raised() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		assertEquals(driver.switchTo().alert().getText(),"Please fill the expiration year");
    	
	}

	@When("^I enter the expiry year and press confirm booking$")
	public void i_enter_the_expiry_year_and_press_confirm_booking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().accept();
		
	    bookingPageBean.setExpiryYear("2025");
	   
	}

	@Then("^Alert for booking confirmation of room is raised$")
	public void alert_for_booking_confirmation_of_room_is_raised() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		 bookingPageBean.setBtn();
		 Thread.sleep(3000);
	}

	@After
	public void closeSetUp()
	{
		driver.close();
	}

}
