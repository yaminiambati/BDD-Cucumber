package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class BookingPageBean {
	WebDriver driver;
	
	@FindBy(name="txtFN")
	private WebElement firstName;
	
	@FindBy(name="txtLN")
	private WebElement lastName;

	@FindBy(name="Email")
	private WebElement email;
	
	@FindBy(name="Phone")
	private WebElement phone;
	
	@FindBy(name="persons")
	private WebElement peopleAttending;
	
	@FindBy(name="Address")
	private WebElement address;
	
	@FindBy(name="rooms")
	private WebElement rooms;
	
	@FindBy(name="city")
	private WebElement city;
	
	@FindBy(name="state")
	private WebElement state;
	
	@FindBy(id="txtCardholderName")
	private WebElement cardHolderName;
	
	@FindBy(name="debit")
	private WebElement dbCardNumber;
	
	@FindBy(name="cvv")
	private WebElement cvv;
	
	@FindBy(name="month")
	private WebElement expiryDate;
	
	@FindBy(name="year")
	private WebElement expiryYear;
	
	
	@FindBy(how=How.XPATH,using="//*[@id=\"btnPayment\"]")
	private WebElement btn;
	
	
    public BookingPageBean(WebDriver driver) {
		
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
    public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName); 
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public void setPhone(String phone) {
		this.phone.sendKeys(phone);
	}

	public void setPeopleAttending(String p) {
		
		// TODO Auto-generated method stub
		Select sel= new Select(peopleAttending);
		sel.selectByVisibleText(p);
	}

	public void setAddress(String address) {
		// TODO Auto-generated method stub
		this.address.sendKeys(address);
	}
	public void setCity(String c) {
		Select sel= new Select(city);
		sel.selectByVisibleText(c);
	}

	public void setState(String s) {
		Select st=new Select(state);
		st.selectByVisibleText(s);
	}

	

	public void setRoomsBooked(String rooms) {
		// TODO Auto-generated method stub
		this.rooms.sendKeys(rooms);
		
	}
	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName.sendKeys(cardHolderName);
	}

	public void setDbCardNumber(String dbCardNumber) {
		this.dbCardNumber.sendKeys(dbCardNumber);
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public void setExpiryMonth(String expiryDate) {
		this.expiryDate.sendKeys(expiryDate);
	}

	public void setExpiryYear(String expiryYear) {
		this.expiryYear.sendKeys(expiryYear);
	}
	public void getPhone() {
		phone.clear();
	}

	public void setBtn() {
		this.btn.click();
	}
	

}
