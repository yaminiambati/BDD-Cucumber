package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPageBean {
	
	WebDriver driver;
	@FindBy(name="userName")
	private WebElement userName;
	
	@FindBy(name="userPwd")
	private WebElement password;
	
	@FindBy(id="pwdErrMsg")
	private WebElement pwderror;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")
	private WebElement btn2;
	
	@FindBy(id="userErrMsg")
	private WebElement usererror;
	
	@FindBy(id="pwdErrMsg")
	private WebElement passworderror;
	
	public LoginPageBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	public void setUserName(String UserName) {
		this.userName.sendKeys(UserName);
	}

	public void setUserPassword(String UserPassword) {
		this.password.sendKeys(UserPassword);
	}
	
	public void setBtn2() {
		this.btn2.click();
	}

	 public String getUser()
	 {
		 return usererror.getText();
	 }
	 public String getPassword()
	 {
		 return pwderror.getText();
	 }
}
