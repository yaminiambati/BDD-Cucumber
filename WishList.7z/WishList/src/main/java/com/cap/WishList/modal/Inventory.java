package com.cap.WishList.modal;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler", "created"})
public class Inventory {
	
	@Id
	@GeneratedValue
	private int productId;
	private String productName;
	
	@OneToMany(targetEntity=WishList.class,mappedBy="inventory")
	private List<WishList> wishList;

	public Inventory(int productId, String productName, List<WishList> wishList) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.wishList = wishList;
	}

	
	public Inventory() {
		
	}


	public int getProductId() {
		return productId;
	}


	public void setProductId(int productId) {
		this.productId = productId;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public List<WishList> getWishList() {
		return wishList;
	}


	public void setWishList(List<WishList> wishList) {
		this.wishList = wishList;
	}
	
	
}
