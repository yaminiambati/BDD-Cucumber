package com.cap.WishList.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.WishList.dao.InventoryDao;
import com.cap.WishList.modal.Inventory;
@Service("inventoryService")
public class InventoryServiceImpl implements InventoryService{
	
	
	@Autowired
	private InventoryDao inventoryDao;

	@Override
	public Inventory findById(Integer prodId) {
		return inventoryDao.getOne(prodId);
	}

}
