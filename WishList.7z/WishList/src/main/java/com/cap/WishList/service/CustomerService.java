package com.cap.WishList.service;

import com.cap.WishList.modal.Customer;

public interface CustomerService {

	Customer findById(Integer custId);

}
