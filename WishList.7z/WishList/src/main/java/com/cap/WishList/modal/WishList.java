package com.cap.WishList.modal;

import java.util.List;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler", "created"})
public class WishList {

	@Id
	@GeneratedValue
	private int wishlist_id;
	
	@ManyToOne
	@JoinColumn(name="product_id")
	private Inventory inventory;
	
	@ManyToOne
	@JoinColumn(name="cust_id")
	private Customer customers;
	
	private boolean isActive;

	

	public WishList(int wishlist_id, Inventory inventory, Customer customers, boolean isActive) {
		super();
		this.wishlist_id = wishlist_id;
		this.inventory = inventory;
		this.customers = customers;
		this.isActive = isActive;
	}

	public WishList() {
		
	}

	public int getWishlist_id() {
		return wishlist_id;
	}

	public void setWishlist_id(int wishlist_id) {
		this.wishlist_id = wishlist_id;
	}

	public Inventory getInventory() {
		return inventory;
	}

	public void setInventory(Inventory inventory) {
		this.inventory = inventory;
	}

	public Customer getCustomers() {
		return customers;
	}

	public void setCustomers(Customer customers) {
		this.customers = customers;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	

}
