package com.cap.WishList.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.WishList.modal.Customer;
import com.cap.WishList.modal.Inventory;
import com.cap.WishList.modal.WishList;
import com.cap.WishList.service.CustomerService;
import com.cap.WishList.service.InventoryService;
import com.cap.WishList.service.WishListService;

@RestController
@RequestMapping("/CapStore/WishList")
public class WishListController {
	
	@Autowired
	private WishListService wishListService;
	
	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private InventoryService inventoryService;
	
	@GetMapping("/wishLists/{custId}")
	public ResponseEntity<List<WishList>> getWishList(@PathVariable("custId") Integer custId) {
		List<WishList> wishList = wishListService.getAll(custId);
		
		System.out.println("Products:" + wishList);
		if(wishList == null || wishList.isEmpty()) {
			return new ResponseEntity("WishList not available", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<WishList>>(wishList, HttpStatus.OK);
	}
	
	@PostMapping("/wishLists/{custId}/{prodId}")
	public ResponseEntity<WishList> createWishList(@PathVariable("custId") Integer custId, @PathVariable("prodId") Integer prodId) {
		WishList wishList = new WishList();
		Customer customer = customerService.findById(custId);
		Inventory inventory = inventoryService.findById(prodId);
		
		wishList.setCustomers(customer);
		wishList.setInventory(inventory);
		wishList.setActive(true);
		wishListService.save(wishList);
		return new ResponseEntity<WishList>(HttpStatus.OK);
	}
	
	@PutMapping("/wishLists/{custId}/{prodId}/{wishId}")
	public ResponseEntity<WishList> updateWishList(@PathVariable("custId") Integer custId, @PathVariable("prodId") Integer prodId,
			@PathVariable("wishId") Integer wishId) {
		
		WishList wishList1 = wishListService.findById(wishId);
		wishList1.setActive(false);
		wishListService.save(wishList1);
		return new ResponseEntity<WishList>(HttpStatus.OK);

	}
}
