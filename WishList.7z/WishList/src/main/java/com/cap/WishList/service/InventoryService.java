package com.cap.WishList.service;

import com.cap.WishList.modal.Inventory;

public interface InventoryService {

	Inventory findById(Integer prodId);

}
