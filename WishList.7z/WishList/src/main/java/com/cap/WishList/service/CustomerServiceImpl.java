package com.cap.WishList.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.WishList.dao.CustomerDao;
import com.cap.WishList.modal.Customer;

@Service("customerService")
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	private CustomerDao customerDao;

	@Override
	public Customer findById(Integer custId) {
		return customerDao.getOne(custId);
	}



}
