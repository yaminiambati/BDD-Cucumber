package com.cap.WishList.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cap.WishList.modal.Customer;
import com.cap.WishList.modal.WishList;

@Repository("customerDao")
@Transactional
public interface CustomerDao  extends JpaRepository<Customer,Integer>{
	
}
