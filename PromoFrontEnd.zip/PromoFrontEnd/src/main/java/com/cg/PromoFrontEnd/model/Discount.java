package com.cg.PromoFrontEnd.model;

import java.util.Date;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


public class Discount {
	
	private int discountId;
	
	private Inventory inventory;
	private int productId;
	private String promoName;
	private double promoAmount;
	private int discountpercent;
	private Date issueDate;
	private Date expiryDate;
	
	public Discount(String promoName) {
		super();
		this.promoName = promoName;
	}
	public int getDiscountId() {
		return discountId;
	}
	public void setDiscountId(int discountId) {
		this.discountId = discountId;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}

	public double getPromoAmount() {
		return promoAmount;
	}
	public void setPromoAmount(double promoAmount) {
		this.promoAmount = promoAmount;
	}
	public int getDiscountpercent() {
		return discountpercent;
	}
	public void setDiscountpercent(int discountpercent) {
		this.discountpercent = discountpercent;
	}
	public Date getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	
	
	public Discount()
	{
		
	}
	

}
