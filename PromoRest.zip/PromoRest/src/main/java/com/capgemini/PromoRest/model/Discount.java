package com.capgemini.PromoRest.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Discount {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int discountId;
	@OneToOne
	@JoinColumn(name="product_id")
	private Inventory inventory;
	
	private String promoName;
	private double promoAmount;
	private int discountpercent;
	private Date issueDate;
	private Date expiryDate;
	
	public Discount(int discountId, Inventory inventory, String promoName, double promoAmount,
			int discountpercent, Date issueDate, Date expiryDate) {
		super();
		this.discountId = discountId;
		this.inventory = inventory;
		this.promoName = promoName;
		this.promoAmount = promoAmount;
		this.discountpercent = discountpercent;
		this.issueDate = issueDate;
		this.expiryDate = expiryDate;
	}
	
	
	public Discount()
	{
		
	}
}
